pidgin_plunin_lol_chat
======================

Pidgin plugin for League of Legends Chat. This plugin help you read user-information more comportable.
